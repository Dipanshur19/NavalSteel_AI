"""Inference adapter for the exported sklearn trees and the browser's Python runtime."""
import json
import math
from array import array
from dataclasses import asdict
from functools import lru_cache
from pathlib import Path
from .physics import evaluate_steel_physics
from .record_reader import extract_from_any_file
from .optimize import run_pareto_optimization

BASE = Path(__file__).resolve().parent.parent
ELEMENTS = ('C','Mn','Si','Ni','Cr','Mo','Cu','V','Nb','Co')


def leaf(tree, features):
    index = 0
    while tree[index][0] >= 0:
        feature, threshold, left, right = tree[index]
        index = left if features[feature] <= threshold else right
    return tree[index][1]


class PortableEnsemble:
    def __init__(self):
        self.models = json.loads((BASE / 'models.json').read_text())

    def predict(self, row):
        physics = evaluate_steel_physics(row)
        values = [row.get(el, 0) for el in ELEMENTS]
        values += [physics[k] for k in ('pcm','ce_iiw','martensite_start_C','bainite_start_C')]
        values += [row[k] for k in ('temper_temp_C','temper_time_h','test_temp_C')]
        return self.estimate(tuple(array('f', values)))

    @lru_cache(maxsize=4096)
    def estimate(self, features):
        results = {}
        for key, model in self.models.items():
            votes = [leaf(tree, features) for tree in model['rf']]
            rf = sum(votes) / len(votes)
            gb = model['init'] + model['rate'] * sum(leaf(tree, features) for tree in model['gb'])
            variance = sum((v - rf)**2 for v in votes) / len(votes)
            uncertainty = math.sqrt(variance + ((rf-gb)/2)**2)
            results[key] = dict(mean=round((rf+gb)/2, 1), uncertainty=round(max(5, uncertainty), 1))
        return results


@lru_cache(maxsize=1)
def ensemble():
    return PortableEnsemble()


def dispatch(action, data):
    if action == 'predict':
        return dict(properties=ensemble().predict(data), physics=evaluate_steel_physics(data))
    if action == 'optimize':
        front = run_pareto_optimization(pop_size=20, generations=6, min_ys_mpa=data['ys'],
            min_cvn_j=data['cvn'], max_pcm=0.30, test_temp_C=data['temp'], surrogate=ensemble())
        unique = {}
        for candidate in front:
            key = tuple(sorted(candidate.composition.items())), tuple(sorted(candidate.processing.items()))
            unique[key] = asdict(candidate)
            unique[key].pop('crowding_distance', None)
        return list(unique.values())
    if action == 'extract':
        record = extract_from_any_file(data['text'].encode(), data['filename'])
        return {k: record[k] for k in ('composition','properties','processing','tables')}
    raise ValueError('Unknown analysis')
